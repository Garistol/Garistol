// script.js: petits comportements
document.getElementById('year').textContent = new Date().getFullYear();

// Smooth scroll for internal links
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click', function(e){
    e.preventDefault();
    const el = document.querySelector(this.getAttribute('href'));
    if(el) el.scrollIntoView({behavior:'smooth', block:'start'});
  });
});

// Optional: basic form submit feedback
const form = document.querySelector('.contact-form');
if(form){
  form.addEventListener('submit', function(e){
    // Let the browser submit normally to Formspree.
    // Show a quick message
    const btn = form.querySelector('button[type="submit"]');
    btn.textContent = 'Envoi...';
    btn.disabled = true;
    setTimeout(()=>{ btn.textContent='Envoyé'; }, 2000);
  });
}
