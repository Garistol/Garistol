# Site statique — Adam Vasseur
Ce dossier contient un site statique (HTML/CSS/JS) prêt à être déployé sur GitHub Pages.

## Contenu
- `index.html` — page principale
- `style.css` — styles
- `script.js` — interactions simples
- `assets/` — place tes images ici (profile-placeholder.jpg, project1.jpg, project2.jpg, ...)

## Formulaire de contact
Le formulaire pointe actuellement vers `https://formspree.io/contact@vasseuradam.fr`.
Deux options :
1. **Simple** : Laisse tel quel — Formspree accepte encore parfois l'email direct comme endpoint mais tu devras vérifier les emails entrants et activer/valider le service si Formspree le demande.
2. **Recommandé** : Crée un formulaire sur Formspree et remplace l'attribut `action` du `<form>` par l'URL fournie par Formspree (ex: `https://formspree.io/f/xxxxx`). Cela garantit une intégration fiable et protège contre le spam.

## Déploiement sur GitHub Pages
1. Crée un dépôt GitHub et mets les fichiers.
2. Dans les paramètres du dépôt → Pages, choisis la branche `main` (ou `gh-pages`) et le dossier `/` comme source.
3. Ton site sera disponible à `https://<ton-utilisateur>.github.io/<nom-du-depot>/`

## Personnalisation rapide
- Remplace les images dans `/assets`.
- Modifie les textes dans `index.html`.
- Change la palette dans `style.css` (variables `--accent`, etc.).

Bonne mise en ligne !
